'use strict';

const EVTC = 'userModel';
/* eslint-disable prefer-const */
let userService = require('../services/userService');
const dataService = require('../common/service');
/* eslint-enable prefer-const */
const logger = require("../utils/logger");
import errorMessages from '../../config/error.messages';

export function getUsers(req) {
    const userService1 = userService();
    let data;
    data = userService1.getUsers();
    data.then((users) => {
        logger.info(EVTC, 'User1 DATA : %s', JSON.stringify(users));
        return users;
    }).catch((error) => {
        logger.info(EVTC, 'error >> %s', JSON.stringify(error));
    });
    return data;
}
export function getUser(id) {
    const userService1 = userService();
    let data;
    return userService1.getUser(id)
    .then((user) => {
        logger.info('User DATA'+ JSON.stringify(user));
        logger.info("Lenghth:"+user.length);
        if(user.length > 0) {
            return user;
        } else {
            logger.info('else');
            return null;
        }
        
    }).catch((error) => {
        logger.info(EVTC, 'error >> %s', JSON.stringify(error));
    });
}
export function createUser(req) {
    logger.info('Line42');
    const userService1 = userService();
    const promise = new Promise((resolve,reject)=> {
        const doesUserExist = userService1.getUser(req.body.username);
        logger.info('Line44');
        doesUserExist.then((userExists) => {
            logger.info('Line45');
            if(userExists.length>0){
                logger.info('Line46');
                const error = {message: errorMessages.USER_ID_EXISTS };
                reject(error.message);
            }
            else {
                logger.info('Line50');
                const data = userService1.createUser(req);
                data.then((user) => {
                    resolve(user);
                }).catch((error) => {
                    reject(error);
                });
            }
        });
     });
    return promise;
}

export function updateUser(req) {
    const userService1 = userService();
    const data = userService1.updateUser(req);
    data.then((user) => {
        logger.info(EVTC, 'User updated %s', req.body.id);
        return user;
    }).catch((error) => {
        logger.info(EVTC, 'error while updating user>> %s', JSON.stringify(error));
    });
    return data;
}

export function deleteUser(req) {
    const userService1 = userService();
    const data = userService1.deleteUser(req);
    data.then((user) => {
    logger.info(EVTC, 'User updated %s', req.body.id);
        return user;
    }).catch((error) => {
        logger.info(EVTC, 'error while updating user>> %s', JSON.stringify(error));
    });
    return data;
}

export function getData(req) {
    const data = dataService(req);
    return data.then((data1) => {
        return data1;
    }).catch((error) => {
        logger.info(EVTC, 'error while fetching data>> %s', JSON.stringify(error));
    });
}