
const databases1= {
    databases : {
        postgres: {
            database: 'postgres',
            username: 'postgres',
            password: 'sudheer',
            host: 'localhost',
            port: '5433',
            schema: 'db',
            dialect: 'postgres',
        }
    }
}

module.exports = databases1;